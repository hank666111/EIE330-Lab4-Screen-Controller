#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build
iverilog -g2005-sv -Wall -s vga_screens -o build/syntax.vvp RTL/*.v > build/syntax.log 2>&1
yosys -Q -T -l build/rtl.log -p '
    read_verilog RTL/pll.v RTL/vga_ctrl.v RTL/button_click.v RTL/screen_ctrl.v RTL/screen_pixels.v RTL/vga_screens.v;
    hierarchy -check -top vga_screens;
    proc; opt; check -assert;
    tee -o build/rtl_stats.json stat -json;
    write_json build/rtl_netlist.json;
    show -format svg -prefix build/vga_screens_rtl vga_screens;
    show -format svg -prefix build/screen_ctrl_rtl screen_ctrl;
    show -format svg -prefix build/button_click_rtl *button_click*;
    show -format svg -prefix build/screen_pixels_rtl screen_pixels;
    synth -top vga_screens; check -assert;
    tee -o build/synth_stats.json stat -json;
    write_json build/synth_netlist.json;
' > build/synthesis_stdout.log 2>&1
if grep -Ei '(^|[^a-z])(warning|error):' build/syntax.log build/rtl.log; then
    printf 'Review diagnostics before using synthesis results.\n' >&2
    exit 1
fi
printf 'Icarus syntax and Yosys checks passed.\n'
