#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p verification
iverilog -V > verification/tool_versions.txt 2>&1
rtl=(RTL/*.v)
for name in pll vga_ctrl button_click screen_ctrl screen_pixels vga_screens; do
    iverilog -g2012 -Wall -I sim -s "${name}_tb" -o "verification/${name}_tb.vvp" "${rtl[@]}" "sim/${name}_tb.v" 2> "verification/${name}_compile.log"
    if [[ -s "verification/${name}_compile.log" ]]; then
        cat "verification/${name}_compile.log"
        exit 1
    fi
    (cd verification && vvp "${name}_tb.vvp") | tee "verification/${name}_test.log"
done
python3 - <<'PY'
from pathlib import Path
import hashlib,json
files=sorted(Path('RTL').glob('*.v'))+sorted(Path('sim').glob('*.v'))+sorted(Path('sim').glob('*.vh'))
Path('verification/tested_source_sha256.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
PY
