#!/usr/bin/env python3
"""Render Lab 4 captured RTL frames and actual VCD/CSV traces. Reuses our Lab 3 plotting utilities.

Run after run_tests.sh. No image is used as a substitute for checking the RTL.
"""
from __future__ import annotations
import json
import re
from pathlib import Path
import numpy as np
from PIL import Image
from PIL import ImageDraw, ImageFont
import csv

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "verification"

def observed_frame():
    words = np.array([int(s, 16) for s in (OUT / "frame_rgb565.hex").read_text().split()], dtype=np.uint16)
    if words.size != 640 * 480:
        raise ValueError(f"Observed frame has {words.size} pixels; expected 307200")
    words = words.reshape(480, 640)
    red = ((words >> 11) & 31).astype(np.uint32) * 255 // 31
    green = ((words >> 5) & 63).astype(np.uint32) * 255 // 63
    blue = (words & 31).astype(np.uint32) * 255 // 31
    rgb = np.stack((red, green, blue), axis=-1).astype(np.uint8)
    Image.fromarray(rgb, "RGB").save(OUT / "observed_frame.png")
    colours, counts = np.unique(words, return_counts=True)
    summary = {
        "source": "frame_rgb565.hex written from simulated top-level rgb output",
        "width": 640, "height": 480, "pixels": int(words.size),
        "unique_rgb565": {f"{int(c):04X}": int(n) for c, n in zip(colours, counts)},
        "nonzero_pixels": int(np.count_nonzero(words)),
        "glyph_box_starts": [[168,208],[248,208],[328,208],[408,208]],
    }
    (OUT / "observed_frame_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary

def read_vcd(path):
    """Keep timestamped changes, including X intervals from bounded dumping."""
    names, changes, scopes = {}, {}, []
    stamp, scale_ns, body = 0, 1.0, False
    lines = path.read_text().splitlines()
    for i, raw in enumerate(lines):
        line = raw.strip()
        if line.startswith("$timescale"):
            value = line.removeprefix("$timescale").replace("$end", "").strip()
            if not value:
                value = lines[i + 1].strip()
            match = re.search(r"(\d+)\s*(s|ms|us|ns|ps|fs)", value)
            if match:
                scale_ns = int(match[1]) * {"s": 1e9, "ms": 1e6, "us": 1e3, "ns": 1, "ps": 1e-3, "fs": 1e-6}[match[2]]
        if line.startswith("$scope"):
            scopes.append(line.split()[2])
        elif line.startswith("$upscope"):
            scopes.pop()
        elif line.startswith("$var"):
            parts = line.split()
            names[".".join(scopes + [parts[4]])] = parts[3]
            changes.setdefault(parts[3], [])
        elif line.startswith("$enddefinitions"):
            body = True
        elif body:
            if line.startswith("#"):
                stamp = int(line[1:])
            elif line and line[0] in "01xXzZ":
                code = line[1:]
                if code in changes:
                    changes[code].append((stamp * scale_ns, int(line[0]) if line[0] in "01" else np.nan))
            elif line and line[0] in "bB":
                bits, code = line[1:].split()
                if code in changes:
                    changes[code].append((stamp * scale_ns, int(bits, 2) if not re.search("[xXzZ]", bits) else np.nan))
    return names, changes

FIG = OUT / "figures"
FIG.mkdir(exist_ok=True)

def font(size):
    for name in ("/System/Library/Fonts/Supplemental/Arial.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"):
        if Path(name).is_file():
            return ImageFont.truetype(name, size)
    return ImageFont.load_default()

def render_traces(selections, start_ns, end_ns, title, filename, unit="us", expected=None, compact=False):
    width, left, right, top, row_h = (1500,215,115,95,86) if compact else (1800,245,70,95,140)
    plot_bottom, plot_amp, axis_bottom = (58,35,68) if compact else (90,65,102)
    image = Image.new("RGB", (width, top + row_h * len(selections) + 95), "white")
    draw = ImageDraw.Draw(image)
    draw.text((left, 23), title, fill="#1d334b", font=font(26 if compact else 29))
    plot_w = width - left - right
    def px(time): return left + (time - start_ns) * plot_w / (end_ns - start_ns)
    divisor = {"ns": 1, "us": 1000, "ms": 1000000}[unit]
    for signal_index, (label, rows, hex_format) in enumerate(selections):
        before = [r for r in rows if r[0] <= start_ns]
        window = ([before[-1]] if before else []) + [r for r in rows if start_ns < r[0] <= end_ns]
        if not window: raise ValueError(f"No recorded data for {label}")
        window[0] = (start_ns, window[0][1])
        window.append((end_ns, window[-1][1]))
        baseline = top + row_h * signal_index
        finite = [r[1] for r in window if np.isfinite(r[1])]
        ymin, ymax = (min(finite), max(finite)) if finite else (0, 1)
        if ymax <= 1: ymin, ymax = 0, 1
        elif ymin == ymax: ymin, ymax = 0, max(1, ymax)
        def py(value): return baseline + plot_bottom - (value-ymin) * plot_amp / max(1, ymax-ymin)
        draw.text((15, baseline + (28 if compact else 41)), label, fill="#17344e", font=font(24 if compact else 23))
        for tick in range(7):
            t = start_ns + (end_ns-start_ns)*tick/6
            xx = px(t)
            draw.line((xx, baseline + 15, xx, baseline + axis_bottom), fill="#e0e6ed", width=1)
        draw.line((left, baseline + axis_bottom, width-right, baseline + axis_bottom), fill="#8193a5", width=1)
        for index in range(len(window)-1):
            (ta, va), (tb, vb) = window[index:index+2]
            if np.isfinite(va):
                draw.line((px(ta),py(va),px(tb),py(va)),fill="#116bb2",width=3)
                if np.isfinite(vb): draw.line((px(tb),py(va),px(tb),py(vb)),fill="#116bb2",width=3)
                if hex_format and px(tb)-px(ta) > 80:
                    value = f"{int(va):04X}" if hex_format == "hex" else str(int(va))
                    draw.text((px(ta)+5,baseline+2),value,fill="#26384b",font=font(23 if compact else 17))
            else:
                draw.line((px(ta),baseline+60,px(tb),baseline+60),fill="#b5b5b5",width=2)
        if expected and label in expected:
            ref = expected[label]
            pts = [(start_ns + (end_ns-start_ns)*i/1800) for i in range(1801)]
            for i in range(0, len(pts)-3, 6):
                yy = py(ref(pts[i]))
                draw.line((px(pts[i]),yy,px(pts[min(i+3,len(pts)-1)]),yy),fill="#d77a1f",width=2)
        draw.text((width-right+8,baseline+(18 if compact else 21)),str(int(ymax)),fill="#5e7184",font=font(20 if compact else 16))
        draw.text((width-right+8,baseline+(50 if compact else 78)),str(int(ymin)),fill="#5e7184",font=font(20 if compact else 16))
    bottom = top + row_h*len(selections)
    for tick in range(7):
        value = (start_ns+(end_ns-start_ns)*tick/6)/divisor
        draw.text((px(start_ns+(end_ns-start_ns)*tick/6)-40,bottom+7),f"{value:.3f}",fill="#4a6075",font=font(21 if compact else 18))
    draw.text((width//2-140,bottom+42),f"Simulation time ({unit})",fill="#26384b",font=font(23))
    if expected:
        draw.text((left+(150 if compact else 480),61),"Blue: measured VCD   Orange dashed: independent expected level",fill="#465b6d",font=font(21 if compact else 18))
    image.save(FIG / filename)

def waveform(vcd_name, selections, start_ns, end_ns, title, filename, expected=None, compact=False):
    names, changes = read_vcd(OUT/vcd_name)
    traces=[]
    for path,label in selections:
        if path not in names: raise KeyError(f"Signal {path} missing from {vcd_name}")
        hex_format = "hex" if label in ("pix_data", "rgb") else ("dec" if label in ("cnt_h", "cnt_v", "pix_x", "pix_y", "counter_q") else None)
        traces.append((label,changes[names[path]],hex_format))
    csv_dir = OUT/"waveform_csv"
    csv_dir.mkdir(exist_ok=True)
    with (csv_dir/filename.replace(".png",".csv")).open("w",newline="") as stream:
        writer=csv.writer(stream)
        writer.writerow(["time_ns","signal","value"])
        for label,rows,_ in traces:
            before=[r for r in rows if r[0] <= start_ns]
            window=([before[-1]] if before else [])+[r for r in rows if start_ns < r[0] <= end_ns]
            writer.writerows((f"{t:.3f}",label,str(int(v)) if np.isfinite(v) else "dump-disabled") for t,v in window)
    render_traces(traces,start_ns,end_ns,title,filename,expected=expected,compact=compact)

def sync_evidence():
    rows = list(csv.DictReader((OUT/"sync_edges.csv").open()))
    good = [(float(r["time_ns"]),int(r["reset_n"]),int(r["hsync"]),int(r["vsync"])) for r in rows if r["hsync"] in "01" and r["vsync"] in "01" and r["reset_n"] in "01"]
    # Only the two complete frames before the explicit mid-picture reset.
    main = [r for r in good if 25 <= r[0] <= 33600020]
    def edges(column, rising):
        return [b[0] for a,b in zip(main,main[1:]) if a[column] != b[column] and b[column] == int(rising)]
    hr,hf,vr,vf=edges(2,True),edges(2,False),edges(3,True),edges(3,False)
    hp=round(hr[1]-hr[0],3); hw=round(next(t for t in hf if t>hr[0])-hr[0],3)
    vp=round(vr[1]-vr[0],3); vw=round(next(t for t in vf if t>vr[0])-vr[0],3)
    summary={"horizontal_period_ns":hp,"horizontal_high_ns":hw,"vertical_period_ns":vp,"vertical_high_ns":vw,"line_rate_hz":1e9/hp,"frame_rate_hz":1e9/vp,"source":"actual hsync/vsync edge events in sync_edges.csv"}
    if (hp,hw,vp,vw)!=(32000,3840,16800000,64000): raise ValueError(summary)
    (OUT/"measured_timing.json").write_text(json.dumps(summary,indent=2)+"\n")
    render_traces([("hsync",[(r[0],r[2]) for r in good],None)],25000,95000,
                  "Measured horizontal sync: 32.00 us period, 3.84 us high","wave_hsync.png")
    render_traces([("vsync",[(r[0],r[3]) for r in good],None)],0,33700000,
                  "Measured vertical sync: 16.80 ms period","wave_vsync.png",unit="ms")
    render_traces([("vsync",[(r[0],r[3]) for r in good],None)],16780000,16900000,
                  "Measured vertical pulse: 64.00 us = 2 scan lines","wave_vsync_pulse.png")
    return summary


def reference_frame(mode):
    colours=[0xffff,0xffe0,0x07ff,0x07e0,0xf81f,0xf800,0x001f,0]
    frame=np.zeros((480,640),dtype=np.uint16)
    if mode==0:
        for i,colour in enumerate(colours):frame[:,i*80:(i+1)*80]=colour
    else:
        fonts=([0xc3e7ffdbc3c3c3c3,0xc3c3c3c3c3c3663c,0x7ec3c07e0303c37e,0xffff181818181818]
               if mode==1 else [0xffc0c0fcc0c0c0ff,0xc3e3f3dbcfc7c3c3,0xfcc6c3c3c3c3c6fc])
        origin=168 if mode==1 else 208
        for i,bits in enumerate(fonts):
            for row in range(8):
                for col in range(8):
                    if (bits>>(63-row*8-col))&1:frame[208+row*8:216+row*8,origin+i*80+col*8:origin+i*80+col*8+8]=0xffff
    return frame

def rgb_image(words):
    red=((words>>11)&31).astype(np.uint32)*255//31
    green=((words>>5)&63).astype(np.uint32)*255//63
    blue=(words&31).astype(np.uint32)*255//31
    return Image.fromarray(np.stack((red,green,blue),axis=-1).astype(np.uint8))

def image_evidence():
    summaries={}
    for mode,label in enumerate(['bars','must','end']):
        expected=reference_frame(mode)
        rgb_image(expected).save(FIG/f'expected_{label}.png')
        for stage in ['pixels','top']:
            name=f'{stage}_{label}.hex'
            words=np.array([int(s,16) for s in (OUT/name).read_text().split()],dtype=np.uint16)
            if words.size!=307200:raise ValueError(f'{name} has {words.size} samples')
            words=words.reshape(480,640)
            mismatch=int(np.count_nonzero(words!=expected))
            if mismatch:raise ValueError(f'{name}: {mismatch} mismatches')
            rgb_image(words).save(FIG/f'{stage}_{label}.png')
            c,n=np.unique(words,return_counts=True)
            summaries[name]={'pixels':307200,'mismatched_pixels':mismatch,'rgb565_counts':{f'{int(a):04X}':int(b) for a,b in zip(c,n)},'white_pixels':int(np.count_nonzero(words==65535))}
    (OUT/'image_comparison.json').write_text(json.dumps(summaries,indent=2)+'\n')
    return summaries

def event_evidence():
    rows=list(csv.DictReader((OUT/'top_control_events.csv').open()))
    vals=[r for r in rows if all(r[k].isdigit() for k in ['reset_n','key_in','click_pulse','state','display_state','counter','armed'])]
    def trace(k):return [(float(r['time_ns']),int(r[k])) for r in vals]
    pulse_rises=[];pulse_widths=[];state_changes=[];display_changes=[];last_rise=None
    for a,b in zip(vals,vals[1:]):
        t=float(b['time_ns'])
        if a['click_pulse']=='0' and b['click_pulse']=='1':pulse_rises.append(t);last_rise=t
        if a['click_pulse']=='1' and b['click_pulse']=='0' and last_rise is not None:pulse_widths.append(t-last_rise)
        if a['state']!=b['state']:state_changes.append({'time_ns':t,'reset_n':int(b['reset_n']),'state':int(b['state'])})
        if a['display_state']!=b['display_state']:display_changes.append({'time_ns':t,'reset_n':int(b['reset_n']),'state':int(b['display_state'])})
    if len(pulse_rises)!=7 or any(abs(w-40)>0.01 for w in pulse_widths):raise ValueError('Unexpected integration click widths/counts')
    summary={'click_count':len(pulse_rises),'click_times_ns':pulse_rises,'click_widths_ns':pulse_widths,'logical_state_changes':state_changes,'display_state_changes':display_changes,'source':'actual top_control_events.csv; no time scaling'}
    delays=[]
    key_falls=[float(b['time_ns']) for a,b in zip(vals,vals[1:]) if a['key_in']=='1' and b['key_in']=='0']
    for i,t in enumerate(pulse_rises):
        last_low=max(z for z in key_falls if z<t)
        change=next(z for z in state_changes if z['time_ns']>=t and z['reset_n']==1)
        shown=next(z for z in display_changes if z['time_ns']>=change['time_ns'] and z['reset_n']==1 and z['state']==change['state'])
        delays.append({'click':i+1,'stable_raw_low_start_ns':last_low,'pulse_ns':t,'state_ns':change['time_ns'],'display_ns':shown['time_ns'],'raw_low_to_pulse_ns':round(t-last_low,3),'state_to_display_ns':round(shown['time_ns']-change['time_ns'],3),'new_state':change['state']})
    summary['click_timing']=delays
    with (OUT/'click_timing.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(delays[0]));w.writeheader();w.writerows(delays)
    (OUT/'control_timing.json').write_text(json.dumps(summary,indent=2)+'\n')
    render_traces([(k,trace(k),'dec' if k in ['state','display_state'] else None) for k in ['key_in','click_pulse','state','display_state']],0,176000000,'Measured full-count clean cycle: one click per press','wave_cycle.png',unit='ms',compact=True)
    render_traces([(k,trace(k),'dec' if k in ['state','display_state'] else None) for k in ['reset_n','key_in','click_pulse','state','display_state']],174000000,300000000,'Measured bounce, long hold and reset while held','wave_bounce_hold_reset.png',unit='ms',compact=True)
    # Generate a continuously recorded control VCD for GTKWave millisecond views.
    path=OUT/'control_events_actual.vcd'
    with path.open('w') as f:
        keys=['reset_n','key_in','click_pulse','state','display_state','counter','armed']
        widths=[1,1,1,2,2,19,1]
        f.write('$date\nActual simulation CSV conversion\n$end\n$timescale 1ps $end\n$scope module lab4_actual_controls $end\n')
        for i,(k,w) in enumerate(zip(keys,widths)):f.write(f'$var wire {w} s{i} {"counter_snapshot" if k=="counter" else k} $end\n')
        f.write('$upscope $end\n$enddefinitions $end\n')
        for r in vals:
            f.write(f"#{round(float(r['time_ns'])*1000)}\n")
            for i,k in enumerate(keys):f.write(f'b{int(r[k]):b} s{i}\n')
    render_traces([(k,trace(k),'dec' if k in ['state','display_state'] else None) for k in ['key_in','click_pulse','state','display_state']],23000000,48000000,'Measured stable press: 20 ms qualification, then one click','wave_debounce_interval.png',unit='ms',compact=True)
    sync_rows=list(csv.DictReader((OUT/'top_sync_edges.csv').open()))
    vs=[(float(r['time_ns']),int(r['vsync'])) for r in sync_rows if r['vsync'] in ['0','1']]
    render_traces([('vsync',vs,None),('state',trace('state'),'dec'),('display_state',trace('display_state'),'dec')],49900000,50700000,'Measured visible-state commit inside vertical blanking','wave_frame_commit.png',unit='ms',compact=True)
    return summary

def sync_timing():
    rows=list(csv.DictReader((OUT/'top_sync_edges.csv').open()))
    good=[(float(r['time_ns']),int(r['reset_n']),int(r['hsync']),int(r['vsync'])) for r in rows if all(r[k] in ['0','1'] for k in ['reset_n','hsync','vsync'])]
    first=[r for r in good if 84<=r[0]<280000000]
    def edges(col,level):return [b[0] for a,b in zip(first,first[1:]) if a[col]!=b[col] and b[col]==level and b[1]==1]
    hr,hf,vr,vf=edges(2,1),edges(2,0),edges(3,1),edges(3,0)
    hp=round(hr[1]-hr[0],3);hw=round(next(t for t in hf if t>hr[0])-hr[0],3)
    vp=round(vr[1]-vr[0],3);vw=round(next(t for t in vf if t>vr[0])-vr[0],3)
    if (hp,hw,vp,vw)!=(32000,3840,16800000,64000):raise ValueError([hp,hw,vp,vw])
    summary={'horizontal_period_ns':hp,'horizontal_high_ns':hw,'vertical_period_ns':vp,'vertical_high_ns':vw,'frame_rate_hz':1e9/vp,'source':'continuously recorded top_sync_edges.csv'}
    (OUT/'measured_timing.json').write_text(json.dumps(summary,indent=2)+'\n')
    render_traces([('hsync',[(r[0],r[2]) for r in good],None)],25000,95000,'Measured horizontal sync: 32 us period, 3.84 us high','wave_hsync.png',compact=True)
    render_traces([('vsync',[(r[0],r[3]) for r in good],None)],0,51000000,'Measured vertical sync: 16.8 ms period','wave_vsync.png',unit='ms',compact=True)
    return summary

if __name__=='__main__':
    print(json.dumps(image_evidence(),indent=2))
    print(json.dumps(event_evidence(),indent=2))
    print(json.dumps(sync_timing(),indent=2))
    names,changes=read_vcd(OUT/'button_click_tb.vcd')
    pulse=changes[names['button_click_tb.click_pulse']]
    first=next(t for t,v in pulse if v==1)
    waveform('button_click_tb.vcd',[(f'button_click_tb.{s}',s) for s in ['key_in','click_pulse']]+[(f'button_click_tb.dut.{s}',s) for s in ['sync_key','counter_q','armed_q']],first-240,first+45,'Measured qualification threshold: 499999, then one 40 ns click','wave_debounce_threshold.png',compact=True)
    p='vga_screens_tb.dut.'
    waveform('vga_screens_tb.vcd',[(p+'vga_ctrl_inst.cnt_h','cnt_h'),(p+'vga_ctrl_inst.pix_data_req','data_req'),(p+'vga_ctrl_inst.rgb_valid','rgb_valid'),(p+'pix_x','pix_x'),('vga_screens_tb.rgb','rgb')],1125580,1126300,'Measured first active pixels: one-clock lookahead','wave_valid.png',compact=True)
    (OUT/'waveform_capture_notes.txt').write_text('Original test VCDs use1ps timestamps. DUT clocks always run at production frequency; $dumpoff disables recording only. Detailed windows cover counter499992..499999 and click, raw-input transitions, frame blanking start and selected scan lines. Continuous control_events_actual.vcd is a lossless representation of logged event snapshots from top_control_events.csv; counter_snapshot is a discrete event-time counter sample, not a continuous counter trace; the clock-accurate threshold VCD supplies counter evidence. Full-frame hex files contain actual simulated outputs, not expected diagrams.\n')
