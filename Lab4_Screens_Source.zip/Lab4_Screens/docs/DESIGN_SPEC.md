# Lab 4 design specification - frozen before RTL implementation

Source: current Moodle Lab_4_Requirements.pdf (8 pages), Lab_4.pdf (29 pages). The lecture slide headed Lab 5 describes button examples; the assessed task is the three-screen state machine.

## Acceptance

One qualified physical click gives exactly one BARS -> MUST -> END -> BARS logical transition. Long holding gives no repeats. Press and release bounce shorter than 20 ms cannot retrigger. Reset overrides every logical/display state; if the switching key is held through reset, release it stably for 20 ms before the next press can count. Normal screen changes occur only in vertical blanking so each active frame contains one screen.

## Interface and modules

- Top `vga_screens #(DEBOUNCE_CYCLES=500000)` inputs sys_clk, sys_rst_n, key_in (both buttons active low), outputs hsync, vsync, rgb[15:0].
- `pll` copied unchanged from Lab 3: sys_clk, sys_rst_n -> vga_clk, 50 MHz / 2.
- `vga_ctrl` copied unchanged from Lab 3: vga_clk, sys_rst_n, pix_data[15:0] -> pix_x[9:0], pix_y[9:0], hsync, vsync, rgb[15:0]. No hierarchical signal references in synthesizable RTL.
- `button_click #(DEBOUNCE_CYCLES=500000)` inputs vga_clk, sys_rst_n, key_in; output click_pulse (one pixel-clock period). Two synchronizer flip-flops; 20 ms stable release initially and after each click to arm; then 20 ms continuously low to emit one click and disarm. Interrupted qualification resets its counter. Internal debug names to document: sync_meta, sync_key, counter_q, armed_q. Final debug naming can be recorded separately without altering this behavior.
- `screen_ctrl` inputs vga_clk, sys_rst_n, click_pulse, vsync; outputs state_q[1:0], display_state_q[1:0]. Moore logical states BARS=00, MUST=01, END=10. Rising vsync, detected with previous_vsync, commits the new desired state during line-zero blanking. If a click coincides with that tick, commit the post-click state. Illegal state recovers to BARS. Separate frame-held displayed-state register is deliberate; logical transition latency is at most one frame to display.
- `screen_pixels` inputs vga_clk, sys_rst_n, pix_x[9:0], pix_y[9:0], display_state[1:0]; output pix_data[15:0], registered with the same one-pixel lookahead alignment as Lab 3.

## Quantified choices

25 MHz pixel clock: 40 ns per pixel; 800 x 525 raster; Hsync high96 pixels=3.84us, Hperiod32us; Vsync high2lines=64us, Vperiod16.8ms=59.5238095Hz (nominal lab 640x480@60). Active h144..783, v35..514; requested x0..639 one cycle earlier at h143..782. Invalid coordinates 1023. 20ms x25MHz=500000 cycles, counter needs19bits (0..499999).

Eight full-height80-pixel vertical bars: WHITE FFFF, YELLOW FFE0, CYAN07FF, GREEN07E0, MAGENTA F81F, RED F800, BLUE001F, BLACK0000. Text white FFFF on black0000. Each glyph8x8 enlarged8x =>64x64, inter-glyph gap16. MUST x168,248,328,408, y208. END x208,288,368, y208. Reuse Lab3 M/U/S/T bitmaps (all now white); define E/N/D by hand with independently checked row/bit convention MSB left.

Asynchronous reset resets divider/controller as in Lab3, so asserted reset stops raster and can blank the virtual window. Logical and display selection become BARS immediately; after reset release the first complete screen is BARS. Do not claim visible running bars while reset is continuously held. The held switching key must not advance that restored BARS screen.

## Evidence required

All six unit/top testbenches; realistic full-count debounce tests plus fast parameter sweeps where labeled; full three-screen pixel oracle checks, sync/valid/pipeline checks, internal counters/state/pulses captured. Plot measured data for report; GTKWave GUI is debugging only. Actual virtual-board full cycle and non-BARS reset video; simulation separately proves mechanical bounce because virtual buttons do not bounce. Generic Yosys cells do not prove FPGA timing closure. One English A4 PDF, names/IDs, confirmed contributions and accurate AI scope in Introduction, IEEE references, GitHub source link and unlisted video link; complete local review package; do not submit Moodle.
